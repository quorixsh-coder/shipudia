# HaShipudia Israeli Grill (Nahariya) site: design proposal

Adapted from the Taktook ordering site for השיפודיה - גריל ישראלי, דוד בן גאון 33, Nahariya.
Phones: 04-6457888 (main), 053-6240297 (deliveries), both from Rest/Zap listings.
Open `index.html` in a browser. Single file, no build step. `CONFIG.demo = true` shows a "design proposal, orders are not sent" banner.

## Not verified, update with the owner before launch
- Menu and prices are a plausible sample (no published menu found). The site says so under the menu. "14 salads" comes from a Rest review.
- Opening hours in `CONFIG.hours` are an example.
- Kosher: Rest lists it as kosher Badatz; confirm the certificate.
- Address number: Zap/Rest say 33, easy.co.il says 30.
- Delivery fee, minimum order, delivery area, WhatsApp number, privacy email, legal name, accessibility coordinator.

## Visuals
No food photos yet: the grill, skewers, pita, plates and sides are inline SVG illustrations. Drink photos are reused from the Taktook set. Real photos can be dropped into `images/` later.

## Privacy and accessibility
Draft privacy policy (Amendment 13) and accessibility statement in `LEGAL` in the script. A lawyer must review before launch.

## Motion
GSAP 3.12.5 + ScrollTrigger and Lenis 1.1.13 vendored in `vendor/`. Embers flicker and smoke rises; off under `prefers-reduced-motion`.
